using comment_microservice.Data;
using comment_microservice.Models;
using MongoDB.Driver;

namespace comment_microservice.Services
{
    public class CommentService
    {
        private readonly CommentDbContext _dbContext;

        public CommentService(CommentDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        // Create
        public async Task<Comment> CreateCommentAsync(Comment comment)
        {
            await _dbContext.Comments.InsertOneAsync(comment);
            return comment;
        }

        // Retrieve by ID
        public async Task<Comment?> GetCommentByIdAsync(string id)
        {
            return await _dbContext.Comments.Find(c => c.Id == id).FirstOrDefaultAsync();
        }

        // Retrieve by Post ID
        public async Task<IEnumerable<Comment>> GetCommentsByPostIdAsync(string postId)
        {
            return await _dbContext.Comments.Find(c => c.PostId == postId).ToListAsync();
        }

        // Update
        public async Task<Comment?> UpdateCommentAsync(string id, string updatedContent)
        {
            var update = Builders<Comment>.Update
                .Set(c => c.Content, updatedContent)
                .Set(c => c.UpdatedAt, DateTime.UtcNow);

            var result = await _dbContext.Comments.FindOneAndUpdateAsync<Comment>(
                c => c.Id == id,
                update,
                new FindOneAndUpdateOptions<Comment>
                {
                    ReturnDocument = ReturnDocument.After
                });

            if (result == null)
            {
                throw new KeyNotFoundException($"No comment found with ID: {id}");
            }

            return result;
        }

        // Delete
        public async Task DeleteCommentAsync(string id)
        {
            var deleteResult = await _dbContext.Comments.DeleteOneAsync(c => c.Id == id);

            if (deleteResult.DeletedCount == 0)
            {
                throw new KeyNotFoundException($"No comment found with ID: {id}");
            }
        }
    }
}
