using Microsoft.Extensions.Options;
using MongoDB.Driver;
using comment_microservice.Models;

namespace comment_microservice.Data
{
    public class CommentDbContext
    {
        private readonly IMongoDatabase _database;

        public CommentDbContext(IOptions<Config.DatabaseSettings> settings)
        {
            // Check if connection string is loaded correctly
            Console.WriteLine($"MongoDB ConnectionString: {settings.Value.ConnectionString}");
            Console.WriteLine($"MongoDB DatabaseName: {settings.Value.DatabaseName}");

            var client = new MongoClient(settings.Value.ConnectionString);
            _database = client.GetDatabase(settings.Value.DatabaseName);
        }

        // Access to Comments collection
        public IMongoCollection<Comment> Comments => _database.GetCollection<Comment>("Comments");
    }
}
