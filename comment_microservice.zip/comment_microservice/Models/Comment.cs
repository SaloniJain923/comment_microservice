using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace comment_microservice.Models
{
    public class Comment
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; } = string.Empty;

        public string PostId { get; set; } = string.Empty; // The ID of the post being commented on.
        public string UserId { get; set; } = string.Empty; // User who made the comment.
        public string Content { get; set; } = string.Empty; // Comment text.
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow; // Timestamp for creation.
        public DateTime? UpdatedAt { get; set; } // Timestamp for last update.
    }
}
