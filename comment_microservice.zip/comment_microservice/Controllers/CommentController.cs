using comment_microservice.Models;
using comment_microservice.Services;
using Microsoft.AspNetCore.Mvc;

namespace comment_microservice.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
public class CommentsController : ControllerBase
{
    private readonly CommentService _commentService;

    public CommentsController(CommentService commentService)
    {
        _commentService = commentService;
    }

    [HttpPost]
    public async Task<IActionResult> CreateComment([FromBody] Comment comment)
    {
        var createdComment = await _commentService.CreateCommentAsync(comment);
        return CreatedAtAction(nameof(GetCommentById), new { id = createdComment.Id }, createdComment);
    }

        // Retrieve by ID
        [HttpGet("{id}")]
        public async Task<IActionResult> GetCommentById(string id)
        {
            var comment = await _commentService.GetCommentByIdAsync(id);
            return comment == null ? NotFound() : Ok(comment);
        }

        // Retrieve by Post ID
        [HttpGet("post/{postId}")]
        public async Task<IActionResult> GetCommentsByPostId(string postId)
        {
            var comments = await _commentService.GetCommentsByPostIdAsync(postId);
            return Ok(comments);
        }

        // Update
        [HttpPut("{id}")]
public async Task<IActionResult> UpdateComment(string id, [FromBody] Comment updatedComment)
{
    if (string.IsNullOrWhiteSpace(updatedComment.Content))
    {
        return BadRequest(new { error = "The content field is required." });
    }

    try
    {
        var result = await _commentService.UpdateCommentAsync(id, updatedComment.Content);
        return Ok(result);
    }
    catch (KeyNotFoundException ex)
    {
        return NotFound(new { error = ex.Message });
    }
}



        // Delete
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteComment(string id)
        {
            await _commentService.DeleteCommentAsync(id);
            return NoContent();
        }
    }
}
